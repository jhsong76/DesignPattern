package Adapter;

public interface Print {
    public abstract void DC_output();
    public abstract void AC_output();

}
