package Adapter;

public class Main {
    public static void main(String[] args) {
        Print p = new Adapter();
        p.DC_output();
    }
}
