package Book;

public interface Aggregate {
    Iterator iterator();
}